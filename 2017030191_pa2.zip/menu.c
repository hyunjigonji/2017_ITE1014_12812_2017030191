#include <stdlib.h>
#include <stdbool.h>
#include "menu.h"

int mainMenu() {
	printf("+------- MENU -------+\n");
	printf("| 1: Add customer    |\n");
	printf("| 2: Delete customer |\n");
	printf("| 3: Search customer |\n");
	printf("| 4: Terminate       |\n");
	printf("+--------------------+\n");

	int menu;
	do {
		printf("menu(1-4)> ");
		scanf("%d", &menu);
		char c;
		while ((c = getchar()) != '\n');
		if (1 <= menu && menu <= 4) {
			break;
		} else {
			printf("Invalid input\n");
		}
	} while (1);

	return menu;
}

void addCustomerMenu(CustomerList *list) {
	Customer new_customer;

	printf("+--- Add customer ---+\n");
	printf("Name(length: 1-%d)> ", MAX_LEN_CUSTOMER_NAME);
	fgets(new_customer.name, sizeof(char) * MAX_LEN_CUSTOMER_NAME, stdin);
	new_customer.name[strlen(new_customer.name) - 1] = '\0';
	printf("Phone number(length: 1-%d)> ", MAX_LEN_CUSTOMER_PHONE_NUMBER);
	fgets(new_customer.phone_number, sizeof(char) * MAX_LEN_CUSTOMER_PHONE_NUMBER, stdin);
	new_customer.phone_number[strlen(new_customer.phone_number) - 1] = '\0';

	addCustomer(list, new_customer);
	printAllCustomers(list);
}

void deleteCustomerMenu(CustomerList *list) {
	printf("+--- Del customer ---+\n");
	printf("| 1: Delete by name  |\n");
	printf("| 2: By phone number |\n");
	printf("| 3: By ID           |\n");
	printf("+--------------------+\n");
	
	printf("menu(1-3)> ");
	int menu;
	scanf("%d", &menu);
	char c;
	while ((c = getchar()) != '\n');
	if (menu == 1) {
		printf("Name(length: 1-%d)> ", MAX_LEN_CUSTOMER_NAME);
		char input_name[MAX_LEN_CUSTOMER_NAME];
		fgets(input_name, sizeof(char) * MAX_LEN_CUSTOMER_NAME, stdin);
		input_name[strlen(input_name) - 1] = '\0';
		NameFindResult result = findCustomerByName(list, input_name);
		if (result.num_result == 0) {
			printf("Name not found.\n");
			return;
		}
		int i;
		for (i = 0; i < result.num_result; i++) {
			int result_index = result.result_arr[i];
			deleteCustomer(list, list->customer_arr[result_index].id);
		}
		
	} else if (menu == 2) {
		printf("Phone number(length: 1-%d)> ", MAX_LEN_CUSTOMER_PHONE_NUMBER);
		char input_phone[MAX_LEN_CUSTOMER_PHONE_NUMBER];
		fgets(input_phone, sizeof(char) * MAX_LEN_CUSTOMER_PHONE_NUMBER, stdin);
		input_phone[strlen(input_phone) - 1] = '\0';
		int result = findCustomerByPhoneNumber(list, input_phone);
		if (result == -1) {
			printf("Phone number not found.\n");
			return;
		}
		deleteCustomer(list, list->customer_arr[result].id);

	} else if (menu == 3) {
		printf("ID> ");
		int input_id;
		scanf("%d", &input_id);
		char c;
		while ((c = getchar()) != '\n');
		int error = deleteCustomer(list, input_id);
		if (error == ID_NOT_FOUND) {
			printf("ID not found.\n");
		}
	}

	printf("Deletion successful.\n");
}

void findCustomerMenu(CustomerList *list) {
	printf("+- Search customers -+\n");
	printf("| 1: Print all       |\n");
	printf("| 2: Search by name  |\n");
	printf("| 3: By phone number |\n");
	printf("| 4: By ID           |\n");
	printf("+--------------------+\n");

	printf("menu(1-4)> ");
	int menu;
	scanf("%d", &menu);
	char c;
	while ((c = getchar()) != '\n');
	if (menu == 1) {
		printAllCustomers(list);
	} else if (menu == 2) {
		printf("Name(length: 1-%d)> ", MAX_LEN_CUSTOMER_NAME);
		char input_name[MAX_LEN_CUSTOMER_NAME];
		fgets(input_name, sizeof(char) * MAX_LEN_CUSTOMER_NAME, stdin);
		input_name[strlen(input_name) - 1] = '\0';
		NameFindResult result = findCustomerByName(list, input_name);
		printf("+-- Customers list --+\n");
		printf("Num\tID\tName\tPhone number\n");
		if (result.num_result == 0) {
			printf("Name not found.\n");
			return;
		}
		int i;
		for (i = 0; i < result.num_result; i++) {
			int result_index = result.result_arr[i];
			printf("%d\t%d\t%s\t%s\n",
				i,
				list->customer_arr[result_index].id,
				list->customer_arr[result_index].name,
				list->customer_arr[result_index].phone_number);
		}

	} else if (menu == 3) {
		printf("Phone number(length: 1-%d)> ", MAX_LEN_CUSTOMER_PHONE_NUMBER);
		char input_phone[MAX_LEN_CUSTOMER_PHONE_NUMBER];
		fgets(input_phone, sizeof(char) * MAX_LEN_CUSTOMER_PHONE_NUMBER, stdin);
		input_phone[strlen(input_phone) - 1] = '\0';
		int result = findCustomerByPhoneNumber(list, input_phone);
		printf("+-- Customers list --+\n");
		printf("Num\tID\tName\tPhone number\n");
		if (result == -1) {
			printf("Phone number not found.\n");
			return;
		}
		printf("1\t%d\t%s\t%s\n",
			list->customer_arr[result].id,
			list->customer_arr[result].name,
			list->customer_arr[result].phone_number);

	} else if (menu == 4) {
		printf("ID> ");
		int input_id;
		scanf("%d", &input_id);
		char c;
		while ((c = getchar()) != '\n');
		int result = findCustomerByID(list, input_id);
		printf("+-- Customers list --+\n");
		printf("Num\tID\tName\tPhone number\n");
		if (result == -1) {
			printf("ID not found.\n");
			return;
		}
		printf("1\t%d\t%s\t%s\n",
			list->customer_arr[result].id,
			list->customer_arr[result].name,
			list->customer_arr[result].phone_number);
	}
}

void printAllCustomers(CustomerList *list) {
	printf("+-- Customers list --+\n");
	printf("Num\tID\tName\tPhone number\n");
	int i, cnt = 0;
	for (i = 0; i < MAX_NUMBER_CUSTOMERS; i++) {
		if (list->customer_arr[i].is_deleted == false) {
			printf("%d\t%d\t%s\t%s\n", 
				cnt++,
				list->customer_arr[i].id,
				list->customer_arr[i].name,
				list->customer_arr[i].phone_number);
		}
	}
}