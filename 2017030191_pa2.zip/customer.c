#include "customer.h"
#include <string.h>

void initCustomerList(CustomerList *list) {
	list->number_of_customers = 0;
	list->cumulated_number_of_customers = 0;
	int i;
	for (i = 0; i < MAX_NUMBER_CUSTOMERS; i++) {
		list->customer_arr[i].is_deleted = true;
	}
}

bool isEmptyCustomerList(CustomerList* list) {
	return (list->number_of_customers == 0);
}
bool isFullCustomerList(CustomerList* list) {
	return (list->number_of_customers == MAX_NUMBER_CUSTOMERS);
}

int addCustomer(CustomerList *list, Customer new_customer) {
	if (isFullCustomerList(list)) {
		return FULL_LIST;
	}
	int found_index = findCustomerByPhoneNumber(list, new_customer.phone_number);
	if (found_index != -1) {
		return EXISTING_PHONE_NUMBER;
	}

	int i;
	for (i = 0; i < MAX_NUMBER_CUSTOMERS; i++) {
		if (list->customer_arr[i].is_deleted) {
			new_customer.id = list->cumulated_number_of_customers;
			new_customer.is_deleted = false;
			list->customer_arr[i] = new_customer;
			list->number_of_customers++;
			list->cumulated_number_of_customers++;
			return 0;
		}
	}
	return 0;
}

int deleteCustomer(CustomerList *list, int ID) {
	if (isEmptyCustomerList(list)) {
		return EMPTY_LIST;
	}
	int found_index = findCustomerByID(list, ID);
	if (found_index == -1) {
		return ID_NOT_FOUND;
	}

	list->customer_arr[found_index].is_deleted = true;
	list->number_of_customers--;
	return 0;
}

NameFindResult findCustomerByName(CustomerList *list, char *name) {
	NameFindResult result;
	result.num_result = 0;

	int i;
	for (i = 0; i < MAX_NUMBER_CUSTOMERS; i++) {
		if (!strcmp(list->customer_arr[i].name, name)) {
			result.result_arr[result.num_result++] = i;
		}
	}

	return result;
}


int findCustomerByPhoneNumber(CustomerList *list, char *phone_number) {
	int i;
	for (i = 0; i < MAX_NUMBER_CUSTOMERS; i++) {
		if (!strcmp(list->customer_arr[i].phone_number, phone_number)) {
			return i;
		}
	}
	return -1;
}

int findCustomerByID(CustomerList *list, int ID) {
	int i;
	for (i = 0; i < MAX_NUMBER_CUSTOMERS; i++) {
		if (list->customer_arr[i].id == ID) {
			return i;
		}
	}
	return -1;
}