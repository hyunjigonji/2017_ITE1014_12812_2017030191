#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include "customer.h"
#include "menu.h"

void(*const subMenus[3])(CustomerList* list) = {
	addCustomerMenu,
	deleteCustomerMenu,
	findCustomerMenu
};

int main() {
	CustomerList customer_list;
	initCustomerList(&customer_list);

	while (true) {
		int menu = mainMenu();
		printf("\n\n");
		if (menu == 4) {	// terminate
			break;
		}
		subMenus[menu - 1](&customer_list);
		printf("\n\n");
	}
	
	return 0;
}