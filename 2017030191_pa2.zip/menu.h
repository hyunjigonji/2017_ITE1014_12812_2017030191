#pragma once
#ifndef __MENU_H__
#define __MENU_H__

#include <stdio.h>
#include "customer.h"

int mainMenu();
void addCustomerMenu(CustomerList *list);
void deleteCustomerMenu(CustomerList *list);
void findCustomerMenu(CustomerList *list);
void printAllCustomers(CustomerList *list);

#endif // !__MENU_H__